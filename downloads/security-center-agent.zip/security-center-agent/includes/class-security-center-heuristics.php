<?php
/**
 * Conservative, local-only file signals used by the Security Center plugin.
 *
 * These checks do not claim to prove that a file is malware. They identify
 * combinations that deserve review and, when safe, a reversible quarantine.
 */

defined( 'ABSPATH' ) || exit;

final class Security_Center_Heuristics {

	/**
	 * @return array<string, mixed>|false
	 */
	public static function inspect( $relative_path, $contents, $is_executable, $is_writable_path ) {
		$path    = strtolower( str_replace( '\\', '/', (string) $relative_path ) );
		$source  = strtolower( (string) $contents );
		$has_php = false !== strpos( $source, '<?php' ) || false !== strpos( $source, '<?=' );

		$obfuscated_execution = self::contains_all( $source, array( 'eval(', 'base64_decode' ) )
			|| self::contains_all( $source, array( 'gzinflate', 'base64_decode' ) )
			|| self::contains_all( $source, array( 'str_rot13', 'base64_decode' ) );
		$process_execution = false !== strpos( $source, 'shell_exec(' )
			|| false !== strpos( $source, 'proc_open(' )
			|| false !== strpos( $source, 'passthru(' );

		if ( $is_writable_path && $is_executable ) {
			$signals = array( 'Executable code is located in a writable upload or cache path.' );
			if ( $obfuscated_execution ) {
				$signals[] = 'It combines encoded or compressed content with dynamic execution.';
			}
			if ( $process_execution ) {
				$signals[] = 'It contains a server-process execution call.';
			}

			return array(
				'kind'          => 'executable_in_writable_path',
				'severity'      => ( $obfuscated_execution || $process_execution ) ? 'critical' : 'high',
				'summary'       => ( $obfuscated_execution || $process_execution )
					? 'High-confidence executable code in a writable path needs review.'
					: 'Executable code in a writable path needs review.',
				'evidence'      => $signals,
				'quarantinable' => true,
			);
		}

		if ( $is_writable_path && ! $is_executable && $has_php ) {
			return array(
				'kind'          => 'disguised_php_payload',
				'severity'      => ( $obfuscated_execution || $process_execution ) ? 'critical' : 'high',
				'summary'       => 'A non-executable filename contains PHP code in a writable path.',
				'evidence'      => array(
					'File extension does not identify this file as PHP.',
					'Its contents include a PHP opening tag.',
				),
				'quarantinable' => true,
			);
		}

		return false;
	}

	private static function contains_all( $source, $needles ) {
		foreach ( $needles as $needle ) {
			if ( false === strpos( $source, $needle ) ) {
				return false;
			}
		}
		return true;
	}
}
