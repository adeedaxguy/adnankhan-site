<?php
/**
 * Plugin Name: Lofts Security Center for WordPress
 * Description: Locally scans high-risk writable paths, safely quarantines reviewable files, and can optionally send signed health heartbeats to a managed Lofts workspace.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Lofts Studio
 * License: GPL-2.0-or-later
 * Text Domain: security-center-agent
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/includes/class-security-center-heuristics.php';

final class Security_Center_Agent {
	const VERSION            = '1.0.0';
	const OPTION_KEY         = 'security_center_agent_connection';
	const FINDINGS_OPTION    = 'security_center_agent_findings';
	const LAST_SCAN_OPTION   = 'security_center_agent_last_scan';
	const AUDIT_OPTION       = 'security_center_agent_audit';
	const CRON_HOOK          = 'security_center_agent_heartbeat';
	const QUARANTINE_DIR     = 'security-center-quarantine';
	const MAX_SCAN_FILES     = 5000;
	const MAX_CONTENT_BYTES  = 262144;

	public static function boot() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_post_security_center_pair', array( __CLASS__, 'handle_pairing' ) );
		add_action( 'admin_post_security_center_heartbeat', array( __CLASS__, 'handle_manual_heartbeat' ) );
		add_action( 'admin_post_security_center_scan', array( __CLASS__, 'handle_scan' ) );
		add_action( 'admin_post_security_center_quarantine', array( __CLASS__, 'handle_quarantine' ) );
		add_action( 'admin_post_security_center_restore', array( __CLASS__, 'handle_restore' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'send_heartbeat' ) );
	}

	public static function activate() {
		self::ensure_quarantine_directory();
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', self::CRON_HOOK );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	public static function register_menu() {
		add_menu_page(
			'Lofts Security Center for WordPress',
			'Lofts Security',
			'manage_options',
			'security-center-agent',
			array( __CLASS__, 'render_admin' ),
			'dashicons-shield-alt',
			58
		);
	}

	public static function render_admin() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$connection = self::get_connection();
		$findings   = self::get_findings();
		$last_scan  = self::get_last_scan();
		$notice     = isset( $_GET['security_center_notice'] ) ? sanitize_key( wp_unslash( $_GET['security_center_notice'] ) ) : '';
		?>
		<div class="wrap">
			<h1>Lofts Security Center for WordPress</h1>
			<p class="description">Scan this WordPress site locally, review explicit evidence, and quarantine only a selected file. No site file is uploaded to Lofts by this scan or quarantine workflow.</p>
			<?php self::render_notice( $notice ); ?>

			<?php if ( ! empty( $connection['agent_id'] ) ) : ?>
				<h2>Managed monitoring connection</h2>
				<table class="widefat striped" style="max-width: 900px">
					<tbody>
						<tr><th>Lofts Security Center</th><td><?php echo esc_html( $connection['platform_url'] ); ?></td></tr>
						<tr><th>Agent ID</th><td><code><?php echo esc_html( $connection['agent_id'] ); ?></code></td></tr>
						<tr><th>Last accepted heartbeat</th><td><?php echo ! empty( $connection['last_heartbeat_at'] ) ? esc_html( $connection['last_heartbeat_at'] ) : 'Not sent yet'; ?></td></tr>
						<tr><th>Protocol</th><td>HTTPS with HMAC-SHA-256, timestamp, and replay-resistant nonce</td></tr>
					</tbody>
				</table>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top: 16px">
					<?php wp_nonce_field( 'security_center_heartbeat' ); ?>
					<input type="hidden" name="action" value="security_center_heartbeat" />
					<?php submit_button( 'Send signed heartbeat now', 'secondary', 'submit', false ); ?>
				</form>
			<?php else : ?>
				<details style="max-width: 900px; margin: 16px 0;">
					<summary><strong>Optional managed monitoring</strong></summary>
					<p>The self-service scan and quarantine flow works without an account, pairing code, or remote connection. If you need portfolio monitoring, Lofts can provision a managed workspace separately.</p>
					<p><a href="https://lofts.studio/#contact">Ask Lofts about managed monitoring</a></p>
				</details>
			<?php endif; ?>

			<hr class="wp-header-end" />
			<h2>Run a local safety scan</h2>
			<p>This scanner stays deliberately conservative. It checks writable upload and cache paths for executable or disguised PHP, and compares core files against WordPress.org checksums. It does not remove files automatically.</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin: 16px 0">
				<?php wp_nonce_field( 'security_center_scan' ); ?>
				<input type="hidden" name="action" value="security_center_scan" />
				<?php submit_button( 'Run local safety scan', 'primary', 'submit', false ); ?>
			</form>
			<?php self::render_scan_summary( $last_scan ); ?>
			<?php self::render_findings( $findings ); ?>

			<hr class="wp-header-end" />
			<h2>Safety boundary</h2>
			<ul class="ul-disc">
				<li>Quarantine moves one reviewed file to a protected local folder and changes its extension so it is no longer executable in place.</li>
				<li>Restore is available for each quarantined file. The plugin never bulk-deletes a finding.</li>
				<li>Core-file mismatches stay review-only; use WordPress updates or a clean reinstall after taking a backup.</li>
				<li>When a finding is uncertain, leave it open and ask a developer or incident-response professional to review it.</li>
			</ul>
		</div>
		<?php
	}

	public static function handle_pairing() {
		self::require_admin_post( 'security_center_pair' );

		$platform_url = isset( $_POST['platform_url'] ) ? wp_unslash( $_POST['platform_url'] ) : '';
		$pairing_token = isset( $_POST['pairing_token'] ) ? trim( wp_unslash( $_POST['pairing_token'] ) ) : '';
		$platform_url = self::normalize_platform_url( $platform_url );

		if ( is_wp_error( $platform_url ) || ! preg_match( '/^[A-Za-z0-9_-]{24,256}$/', $pairing_token ) ) {
			self::redirect_with_notice( 'pairing_failed' );
		}

		$response = wp_safe_remote_post(
			$platform_url . '/api/v1/agent/pair',
			array(
				'timeout' => 15,
				'sslverify' => true,
				'headers' => array( 'Content-Type' => 'application/json', 'Accept' => 'application/json' ),
				'body' => wp_json_encode(
					array(
						'pairingToken' => $pairing_token,
						'agentVersion' => self::VERSION,
						'capabilities' => self::capabilities(),
					),
					JSON_UNESCAPED_SLASHES
				),
			)
		);

		if ( is_wp_error( $response ) || 201 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			self::redirect_with_notice( 'pairing_failed' );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) || empty( $body['agentId'] ) || empty( $body['keyId'] ) || empty( $body['sharedSecret'] ) ) {
			self::redirect_with_notice( 'pairing_failed' );
		}

		$encrypted_secret = self::encrypt_secret( $body['sharedSecret'] );
		if ( is_wp_error( $encrypted_secret ) ) {
			self::redirect_with_notice( 'pairing_failed' );
		}

		update_option(
			self::OPTION_KEY,
			array(
				'platform_url' => $platform_url,
				'agent_id' => sanitize_text_field( $body['agentId'] ),
				'key_id' => sanitize_text_field( $body['keyId'] ),
				'secret' => $encrypted_secret,
				'paired_at' => current_time( 'mysql', true ),
				'last_heartbeat_at' => '',
			),
			false
		);

		self::add_audit( 'Paired this site with Lofts Security Center. The one-time connection code was not stored.' );
		self::redirect_with_notice( 'paired' );
	}

	public static function handle_manual_heartbeat() {
		self::require_admin_post( 'security_center_heartbeat' );
		$result = self::send_heartbeat();
		self::redirect_with_notice( is_wp_error( $result ) ? 'heartbeat_failed' : 'heartbeat_sent' );
	}

	public static function handle_scan() {
		self::require_admin_post( 'security_center_scan' );
		$result = self::scan_site();
		self::redirect_with_notice( is_wp_error( $result ) ? 'scan_failed' : 'scan_finished' );
	}

	public static function handle_quarantine() {
		$finding_id = isset( $_POST['finding_id'] ) ? sanitize_text_field( wp_unslash( $_POST['finding_id'] ) ) : '';
		self::require_admin_post( 'security_center_quarantine_' . $finding_id );
		$result = self::quarantine_finding( $finding_id );
		self::redirect_with_notice( is_wp_error( $result ) ? 'quarantine_failed' : 'quarantined' );
	}

	public static function handle_restore() {
		$finding_id = isset( $_POST['finding_id'] ) ? sanitize_text_field( wp_unslash( $_POST['finding_id'] ) ) : '';
		self::require_admin_post( 'security_center_restore_' . $finding_id );
		$result = self::restore_finding( $finding_id );
		self::redirect_with_notice( is_wp_error( $result ) ? 'restore_failed' : 'restored' );
	}

	/**
	 * Send the smallest useful health signal. Site file content never leaves WordPress.
	 */
	public static function send_heartbeat() {
		$connection = self::get_connection();
		if ( empty( $connection['platform_url'] ) || empty( $connection['agent_id'] ) || empty( $connection['secret'] ) ) {
			return new WP_Error( 'security_center_unpaired', 'The plugin is not connected to Lofts Security Center.' );
		}

		$secret = self::decrypt_secret( $connection['secret'] );
		if ( is_wp_error( $secret ) ) {
			return $secret;
		}

		$path = '/api/v1/agent/' . rawurlencode( $connection['agent_id'] ) . '/heartbeat';
		$body = wp_json_encode(
			array(
				'agentVersion' => self::VERSION,
				'capabilities' => self::capabilities(),
				'health' => self::health_from_findings(),
			),
			JSON_UNESCAPED_SLASHES
		);
		$timestamp = gmdate( 'c' );
		try {
			$nonce = rtrim( strtr( base64_encode( random_bytes( 24 ) ), '+/', '-_' ), '=' );
		} catch ( Exception $exception ) {
			return new WP_Error( 'security_center_nonce_failed', 'Could not create a secure request nonce.' );
		}

		$canonical = "POST\n" . $path . "\n" . $timestamp . "\n" . $nonce . "\n" . hash( 'sha256', $body );
		$signature = hash_hmac( 'sha256', $canonical, $secret );
		$response = wp_safe_remote_post(
			$connection['platform_url'] . $path,
			array(
				'timeout' => 15,
				'sslverify' => true,
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept' => 'application/json',
					'X-Security-Center-Timestamp' => $timestamp,
					'X-Security-Center-Nonce' => $nonce,
					'X-Security-Center-Signature' => $signature,
				),
				'body' => $body,
			)
		);

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'security_center_heartbeat_rejected', 'Lofts Security Center did not accept the signed heartbeat.' );
		}

		$connection['last_heartbeat_at'] = current_time( 'mysql', true );
		update_option( self::OPTION_KEY, $connection, false );
		return true;
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	private static function scan_site() {
		$notes = array();
		$scanned_files = 0;
		$findings = array();

		foreach ( self::writable_scan_roots() as $root ) {
			$result = self::scan_writable_root( $root, $scanned_files, $notes );
			if ( is_wp_error( $result ) ) {
				$notes[] = $result->get_error_message();
				continue;
			}
			$findings = array_merge( $findings, $result );
			if ( $scanned_files >= self::MAX_SCAN_FILES ) {
				$notes[] = 'The local scan reached its 5,000-file safety limit. Review the most recent paths and scan again after narrowing the site storage.';
				break;
			}
		}

		$findings = array_merge( $findings, self::scan_core_integrity( $notes ) );
		$existing = self::get_findings();
		$merged = $findings;
		foreach ( $existing as $finding ) {
			if ( 'quarantined' === $finding['status'] ) {
				$merged[] = $finding;
			}
		}

		usort(
			$merged,
			function( $left, $right ) {
				$order = array( 'critical' => 0, 'high' => 1, 'medium' => 2, 'low' => 3, 'info' => 4 );
				return ( $order[ $left['severity'] ] ?? 9 ) <=> ( $order[ $right['severity'] ] ?? 9 );
			}
		);

		$last_scan = array(
			'completed_at' => current_time( 'mysql', true ),
			'scanned_files' => $scanned_files,
			'active_findings' => count( array_filter( $merged, array( __CLASS__, 'is_active_finding' ) ) ),
			'notes' => array_slice( $notes, 0, 4 ),
		);
		update_option( self::FINDINGS_OPTION, $merged, false );
		update_option( self::LAST_SCAN_OPTION, $last_scan, false );
		self::add_audit( sprintf( 'Completed local safety scan: %d files checked and %d active findings.', $scanned_files, $last_scan['active_findings'] ) );
		return $last_scan;
	}

	private static function scan_writable_root( $root, &$scanned_files, &$notes ) {
		$findings = array();
		$root_path = isset( $root['path'] ) ? $root['path'] : '';
		if ( ! $root_path || ! is_dir( $root_path ) || ! is_readable( $root_path ) ) {
			return new WP_Error( 'security_center_scan_root', 'A writable WordPress storage path could not be read.' );
		}

		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $root_path, FilesystemIterator::SKIP_DOTS ),
				RecursiveIteratorIterator::LEAVES_ONLY
			);
			foreach ( $iterator as $item ) {
				if ( $scanned_files >= self::MAX_SCAN_FILES ) {
					break;
				}
				if ( ! $item->isFile() || $item->isLink() || ! $item->isReadable() ) {
					continue;
				}
				$scanned_files++;
				$path = $item->getPathname();
				$relative = self::relative_path( $path );
				if ( ! $relative || false !== strpos( $relative, self::QUARANTINE_DIR . '/' ) ) {
					continue;
				}
				$extension = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
				$is_executable = in_array( $extension, array( 'php', 'php3', 'php4', 'php5', 'php7', 'phtml', 'phar', 'inc' ), true );
				$is_possible_payload = $is_executable || in_array( $extension, array( 'jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'txt', 'html', 'htm', 'js', 'css', 'pdf' ), true );
				if ( ! $is_possible_payload ) {
					continue;
				}
				$contents = self::read_file_prefix( $path );
				$signal = Security_Center_Heuristics::inspect( $relative, $contents, $is_executable, true );
				if ( ! $signal ) {
					continue;
				}
				$findings[] = self::make_finding( $relative, $path, $signal );
			}
		} catch ( UnexpectedValueException $exception ) {
			$notes[] = 'A directory could not be fully read during the local scan.';
		}

		return $findings;
	}

	private static function scan_core_integrity( &$notes ) {
		if ( ! function_exists( 'get_core_checksums' ) && file_exists( ABSPATH . 'wp-admin/includes/update.php' ) ) {
			require_once ABSPATH . 'wp-admin/includes/update.php';
		}
		if ( ! function_exists( 'get_core_checksums' ) ) {
			$notes[] = 'WordPress core checksums are not available on this installation.';
			return array();
		}

		global $wp_version, $wp_local_package;
		$locale = ! empty( $wp_local_package ) ? $wp_local_package : get_locale();
		$checksums = get_core_checksums( $wp_version, $locale );
		if ( ! is_array( $checksums ) ) {
			$notes[] = 'WordPress core checksums could not be retrieved. The writable-path scan still completed.';
			return array();
		}

		$findings = array();
		foreach ( $checksums as $relative => $checksum ) {
			if ( 0 === strpos( $relative, 'wp-content/' ) ) {
				continue;
			}
			$path = ABSPATH . $relative;
			if ( ! is_file( $path ) || ! is_readable( $path ) ) {
				continue;
			}
			$actual = @md5_file( $path );
			if ( false === $actual || hash_equals( strtolower( $checksum ), strtolower( $actual ) ) ) {
				continue;
			}
			$findings[] = self::make_finding(
				$relative,
				$path,
				array(
					'kind' => 'core_checksum_mismatch',
					'severity' => 'high',
					'summary' => 'A WordPress core file does not match the official checksum.',
					'evidence' => array( 'The installed file differs from the checksum published for this WordPress version and locale.' ),
					'quarantinable' => false,
				)
			);
		}
		return $findings;
	}

	private static function quarantine_finding( $finding_id ) {
		$findings = self::get_findings();
		$index = self::find_finding_index( $findings, $finding_id );
		if ( false === $index || empty( $findings[ $index ]['quarantinable'] ) || 'open' !== $findings[ $index ]['status'] ) {
			return new WP_Error( 'security_center_quarantine_denied', 'That finding cannot be quarantined. Run a fresh scan and review the result again.' );
		}

		$finding = $findings[ $index ];
		$source = self::resolve_live_file( $finding['relative_path'] );
		if ( is_wp_error( $source ) || ! self::is_quarantine_target( $source ) ) {
			return new WP_Error( 'security_center_quarantine_path', 'The selected file is outside the local quarantine boundary.' );
		}
		$current_hash = @hash_file( 'sha256', $source );
		if ( ! $current_hash || ! hash_equals( $finding['sha256'], $current_hash ) ) {
			return new WP_Error( 'security_center_quarantine_changed', 'The file changed after the scan. Run a fresh scan before quarantining it.' );
		}

		$quarantine_dir = self::ensure_quarantine_directory();
		if ( is_wp_error( $quarantine_dir ) ) {
			return $quarantine_dir;
		}
		try {
			$name = hash( 'sha256', $finding['relative_path'] . '|' . microtime( true ) . '|' . random_bytes( 16 ) ) . '.quarantined';
		} catch ( Exception $exception ) {
			return new WP_Error( 'security_center_quarantine_nonce', 'Could not create a safe quarantine filename.' );
		}
		$destination = trailingslashit( $quarantine_dir ) . $name;
		if ( ! @rename( $source, $destination ) ) {
			return new WP_Error( 'security_center_quarantine_move', 'WordPress could not move this file into the protected quarantine folder.' );
		}

		$findings[ $index ]['status'] = 'quarantined';
		$findings[ $index ]['quarantine_name'] = $name;
		$findings[ $index ]['quarantined_at'] = current_time( 'mysql', true );
		$findings[ $index ]['quarantined_by'] = get_current_user_id();
		update_option( self::FINDINGS_OPTION, $findings, false );
		self::add_audit( 'Quarantined ' . $finding['relative_path'] . '. The original path is no longer executable and can be restored from this screen.' );
		return true;
	}

	private static function restore_finding( $finding_id ) {
		$findings = self::get_findings();
		$index = self::find_finding_index( $findings, $finding_id );
		if ( false === $index || 'quarantined' !== $findings[ $index ]['status'] || empty( $findings[ $index ]['quarantine_name'] ) ) {
			return new WP_Error( 'security_center_restore_denied', 'That file is not available for restore.' );
		}

		$finding = $findings[ $index ];
		$quarantine_dir = self::ensure_quarantine_directory();
		if ( is_wp_error( $quarantine_dir ) ) {
			return $quarantine_dir;
		}
		$quarantine_name = sanitize_file_name( $finding['quarantine_name'] );
		$source = trailingslashit( $quarantine_dir ) . $quarantine_name;
		if ( ! is_file( $source ) || ! is_readable( $source ) ) {
			return new WP_Error( 'security_center_restore_missing', 'The quarantined copy is missing. It was not restored.' );
		}
		$current_hash = @hash_file( 'sha256', $source );
		if ( ! $current_hash || ! hash_equals( $finding['sha256'], $current_hash ) ) {
			return new WP_Error( 'security_center_restore_changed', 'The quarantined copy changed. It was not restored.' );
		}

		$destination = self::restore_destination( $finding['relative_path'] );
		if ( is_wp_error( $destination ) || file_exists( $destination ) ) {
			return new WP_Error( 'security_center_restore_path', 'The original path is no longer safe to restore. It was left in quarantine.' );
		}
		if ( ! @rename( $source, $destination ) ) {
			return new WP_Error( 'security_center_restore_move', 'WordPress could not restore this file. It remains quarantined.' );
		}

		$findings[ $index ]['status'] = 'restored';
		$findings[ $index ]['restored_at'] = current_time( 'mysql', true );
		update_option( self::FINDINGS_OPTION, $findings, false );
		self::add_audit( 'Restored ' . $finding['relative_path'] . ' from quarantine at the administrator’s request.' );
		return true;
	}

	private static function render_notice( $notice ) {
		$messages = array(
			'paired' => array( 'success', 'Connected securely. The one-time connection code was not retained.' ),
			'pairing_failed' => array( 'error', 'Connection failed. Check the HTTPS URL and generate a fresh one-time code in Lofts Security Center.' ),
			'heartbeat_sent' => array( 'success', 'A signed heartbeat was accepted.' ),
			'heartbeat_failed' => array( 'error', 'The signed heartbeat was not accepted. Re-pair with a fresh code if the connection changed.' ),
			'scan_finished' => array( 'success', 'The local safety scan completed. Review each finding before taking action.' ),
			'scan_failed' => array( 'error', 'The local safety scan could not complete. Check WordPress file permissions and try again.' ),
			'quarantined' => array( 'success', 'The selected file was moved to local quarantine. Its original path is no longer executable.' ),
			'quarantine_failed' => array( 'error', 'The file was not quarantined. It may have changed after the scan or WordPress could not move it.' ),
			'restored' => array( 'success', 'The selected file was restored from local quarantine.' ),
			'restore_failed' => array( 'error', 'The file remains in quarantine because it could not be restored safely.' ),
		);
		if ( ! isset( $messages[ $notice ] ) ) {
			return;
		}
		?>
		<div class="notice notice-<?php echo esc_attr( $messages[ $notice ][0] ); ?> is-dismissible"><p><?php echo esc_html( $messages[ $notice ][1] ); ?></p></div>
		<?php
	}

	private static function render_scan_summary( $last_scan ) {
		if ( empty( $last_scan['completed_at'] ) ) {
			echo '<p><em>No local scan has run yet.</em></p>';
			return;
		}
		?>
		<p><strong>Last local scan:</strong> <?php echo esc_html( $last_scan['completed_at'] ); ?>. <?php echo esc_html( (string) $last_scan['scanned_files'] ); ?> files checked; <?php echo esc_html( (string) $last_scan['active_findings'] ); ?> active findings.</p>
		<?php if ( ! empty( $last_scan['notes'] ) ) : ?>
			<ul class="ul-disc">
				<?php foreach ( $last_scan['notes'] as $note ) : ?>
					<li><?php echo esc_html( $note ); ?></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
		<?php
	}

	private static function render_findings( $findings ) {
		$visible = array_filter(
			$findings,
			function( $finding ) {
				return 'restored' !== $finding['status'];
			}
		);
		if ( empty( $visible ) ) {
			echo '<div class="notice notice-success inline"><p>No active or quarantined findings are recorded. A clean result is not a guarantee that a site is secure.</p></div>';
			return;
		}
		?>
		<table class="widefat striped" style="max-width: 1200px">
			<thead><tr><th>Risk</th><th>File</th><th>Evidence</th><th>Safe action</th></tr></thead>
			<tbody>
				<?php foreach ( $visible as $finding ) : ?>
					<tr>
						<td><strong><?php echo esc_html( ucfirst( $finding['severity'] ) ); ?></strong><br /><span class="description"><?php echo esc_html( ucfirst( $finding['status'] ) ); ?></span></td>
						<td><code><?php echo esc_html( $finding['relative_path'] ); ?></code></td>
						<td><strong><?php echo esc_html( $finding['summary'] ); ?></strong><ul class="ul-disc"><?php foreach ( $finding['evidence'] as $evidence ) : ?><li><?php echo esc_html( $evidence ); ?></li><?php endforeach; ?></ul></td>
						<td><?php self::render_finding_action( $finding ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	private static function render_finding_action( $finding ) {
		if ( 'quarantined' === $finding['status'] ) {
			?>
			<p>Local copy retained with a non-executable extension.</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'security_center_restore_' . $finding['id'] ); ?>
				<input type="hidden" name="action" value="security_center_restore" />
				<input type="hidden" name="finding_id" value="<?php echo esc_attr( $finding['id'] ); ?>" />
				<?php submit_button( 'Restore from quarantine', 'secondary small', 'submit', false ); ?>
			</form>
			<?php
			return;
		}
		if ( empty( $finding['quarantinable'] ) ) {
			?>
			<p>Do not quarantine a WordPress core file from this plugin.</p>
			<p><a class="button button-secondary" href="<?php echo esc_url( admin_url( 'update-core.php' ) ); ?>">Review WordPress updates</a></p>
			<?php
			return;
		}
		?>
		<p>Moves only this reviewed file to local quarantine. It does not delete it.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'security_center_quarantine_' . $finding['id'] ); ?>
			<input type="hidden" name="action" value="security_center_quarantine" />
			<input type="hidden" name="finding_id" value="<?php echo esc_attr( $finding['id'] ); ?>" />
			<?php submit_button( 'Quarantine safely', 'delete small', 'submit', false ); ?>
		</form>
		<?php
	}

	private static function get_connection() {
		$connection = get_option( self::OPTION_KEY, array() );
		return is_array( $connection ) ? $connection : array();
	}

	private static function get_findings() {
		$findings = get_option( self::FINDINGS_OPTION, array() );
		if ( ! is_array( $findings ) ) {
			return array();
		}
		return array_values( array_filter( $findings, 'is_array' ) );
	}

	private static function get_last_scan() {
		$scan = get_option( self::LAST_SCAN_OPTION, array() );
		return is_array( $scan ) ? $scan : array();
	}

	private static function capabilities() {
		return array( 'scan_file', 'quarantine_file', 'restore_verified_file' );
	}

	private static function health_from_findings() {
		foreach ( self::get_findings() as $finding ) {
			if ( self::is_active_finding( $finding ) && in_array( $finding['severity'], array( 'critical', 'high' ), true ) ) {
				return 'degraded';
			}
		}
		return 'healthy';
	}

	private static function is_active_finding( $finding ) {
		return isset( $finding['status'] ) && 'open' === $finding['status'];
	}

	private static function writable_scan_roots() {
		$roots = array();
		$uploads = wp_upload_dir();
		if ( empty( $uploads['error'] ) && ! empty( $uploads['basedir'] ) && is_dir( $uploads['basedir'] ) ) {
			$roots[] = array( 'path' => realpath( $uploads['basedir'] ) );
		}
		$cache = WP_CONTENT_DIR . '/cache';
		if ( is_dir( $cache ) ) {
			$roots[] = array( 'path' => realpath( $cache ) );
		}
		$unique = array();
		foreach ( $roots as $root ) {
			if ( ! empty( $root['path'] ) ) {
				$unique[ wp_normalize_path( $root['path'] ) ] = $root;
			}
		}
		return array_values( $unique );
	}

	private static function make_finding( $relative_path, $absolute_path, $signal ) {
		$sha256 = @hash_file( 'sha256', $absolute_path );
		if ( ! $sha256 ) {
			$sha256 = '';
		}
		return array(
			'id' => substr( hash( 'sha256', $signal['kind'] . '|' . $relative_path . '|' . $sha256 ), 0, 32 ),
			'kind' => $signal['kind'],
			'severity' => $signal['severity'],
			'summary' => $signal['summary'],
			'evidence' => $signal['evidence'],
			'relative_path' => $relative_path,
			'sha256' => $sha256,
			'quarantinable' => ! empty( $signal['quarantinable'] ),
			'status' => 'open',
			'first_observed_at' => current_time( 'mysql', true ),
		);
	}

	private static function relative_path( $path ) {
		$root = trailingslashit( wp_normalize_path( realpath( ABSPATH ) ) );
		$path = wp_normalize_path( realpath( $path ) );
		if ( ! $path || 0 !== strpos( $path, $root ) ) {
			return '';
		}
		return ltrim( substr( $path, strlen( $root ) ), '/' );
	}

	private static function read_file_prefix( $path ) {
		$contents = @file_get_contents( $path, false, null, 0, self::MAX_CONTENT_BYTES );
		return false === $contents ? '' : $contents;
	}

	private static function find_finding_index( $findings, $finding_id ) {
		foreach ( $findings as $index => $finding ) {
			if ( ! empty( $finding['id'] ) && hash_equals( $finding['id'], $finding_id ) ) {
				return $index;
			}
		}
		return false;
	}

	private static function resolve_live_file( $relative_path ) {
		$relative_path = ltrim( str_replace( '\\', '/', (string) $relative_path ), '/' );
		if ( '' === $relative_path || false !== strpos( $relative_path, '..' ) ) {
			return new WP_Error( 'security_center_invalid_path', 'The finding path is invalid.' );
		}
		$path = realpath( ABSPATH . $relative_path );
		if ( ! $path || ! is_file( $path ) || ! self::is_inside_wordpress_root( $path ) ) {
			return new WP_Error( 'security_center_missing_path', 'The selected file no longer exists in the expected WordPress path.' );
		}
		return $path;
	}

	private static function restore_destination( $relative_path ) {
		$relative_path = ltrim( str_replace( '\\', '/', (string) $relative_path ), '/' );
		if ( '' === $relative_path || false !== strpos( $relative_path, '..' ) ) {
			return new WP_Error( 'security_center_invalid_restore_path', 'The restore path is invalid.' );
		}
		$destination = wp_normalize_path( ABSPATH . $relative_path );
		$parent = realpath( dirname( $destination ) );
		if ( ! $parent || ! self::is_inside_wordpress_root( $parent ) || ! self::is_quarantine_target( $parent ) ) {
			return new WP_Error( 'security_center_invalid_restore_path', 'The original directory is not inside the local quarantine boundary.' );
		}
		return $destination;
	}

	private static function is_inside_wordpress_root( $path ) {
		$root = trailingslashit( wp_normalize_path( realpath( ABSPATH ) ) );
		$path = wp_normalize_path( $path );
		return 0 === strpos( $path, $root );
	}

	private static function is_quarantine_target( $path ) {
		$normalized_path = wp_normalize_path( $path );
		foreach ( self::writable_scan_roots() as $root ) {
			$normalized_root = untrailingslashit( wp_normalize_path( $root['path'] ) );
			if ( $normalized_path === $normalized_root || 0 === strpos( $normalized_path, trailingslashit( $normalized_root ) ) ) {
				return true;
			}
		}
		return false;
	}

	private static function ensure_quarantine_directory() {
		$directory = WP_CONTENT_DIR . '/' . self::QUARANTINE_DIR;
		if ( ! is_dir( $directory ) && ! wp_mkdir_p( $directory ) ) {
			return new WP_Error( 'security_center_quarantine_directory', 'WordPress could not create the protected quarantine folder.' );
		}
		@file_put_contents( trailingslashit( $directory ) . '.htaccess', "Deny from all\nOptions -Indexes\n" );
		@file_put_contents( trailingslashit( $directory ) . 'web.config', "<configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>" );
		@file_put_contents( trailingslashit( $directory ) . 'index.html', '' );
		return $directory;
	}

	private static function add_audit( $summary ) {
		$audit = get_option( self::AUDIT_OPTION, array() );
		$audit = is_array( $audit ) ? $audit : array();
		array_unshift(
			$audit,
			array(
				'at' => current_time( 'mysql', true ),
				'user_id' => get_current_user_id(),
				'summary' => sanitize_text_field( $summary ),
			)
		);
		update_option( self::AUDIT_OPTION, array_slice( $audit, 0, 100 ), false );
	}

	private static function require_admin_post( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to manage this security plugin.', 'security-center-agent' ), 403 );
		}
		check_admin_referer( $action );
	}

	private static function normalize_platform_url( $url ) {
		$url = esc_url_raw( trim( $url ) );
		$parts = wp_parse_url( $url );
		if ( empty( $parts['scheme'] ) || 'https' !== strtolower( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return new WP_Error( 'security_center_invalid_url', 'Lofts Security Center must use HTTPS.' );
		}
		if ( ! empty( $parts['user'] ) || ! empty( $parts['pass'] ) || ! empty( $parts['query'] ) || ! empty( $parts['fragment'] ) ) {
			return new WP_Error( 'security_center_invalid_url', 'The Lofts Security Center URL is malformed.' );
		}
		$path = isset( $parts['path'] ) ? untrailingslashit( $parts['path'] ) : '';
		if ( '' !== $path ) {
			return new WP_Error( 'security_center_invalid_url', 'The Lofts Security Center URL cannot contain a path.' );
		}
		return untrailingslashit( $url );
	}

	private static function encryption_key() {
		return hash( 'sha256', wp_salt( 'auth' ), true );
	}

	private static function encrypt_secret( $secret ) {
		if ( ! function_exists( 'openssl_encrypt' ) || ! function_exists( 'random_bytes' ) ) {
			return new WP_Error( 'security_center_crypto_unavailable', 'Required encryption support is unavailable.' );
		}
		try {
			$iv = random_bytes( 12 );
		} catch ( Exception $exception ) {
			return new WP_Error( 'security_center_crypto_failed', 'Could not create encryption material.' );
		}
		$tag = '';
		$ciphertext = openssl_encrypt( $secret, 'aes-256-gcm', self::encryption_key(), OPENSSL_RAW_DATA, $iv, $tag );
		if ( false === $ciphertext || empty( $tag ) ) {
			return new WP_Error( 'security_center_crypto_failed', 'Could not protect the shared secret.' );
		}
		return base64_encode( $iv . $tag . $ciphertext );
	}

	private static function decrypt_secret( $encrypted ) {
		if ( ! function_exists( 'openssl_decrypt' ) ) {
			return new WP_Error( 'security_center_crypto_unavailable', 'Required encryption support is unavailable.' );
		}
		$decoded = base64_decode( $encrypted, true );
		if ( false === $decoded || strlen( $decoded ) < 29 ) {
			return new WP_Error( 'security_center_crypto_failed', 'The saved shared secret cannot be read.' );
		}
		$iv = substr( $decoded, 0, 12 );
		$tag = substr( $decoded, 12, 16 );
		$ciphertext = substr( $decoded, 28 );
		$secret = openssl_decrypt( $ciphertext, 'aes-256-gcm', self::encryption_key(), OPENSSL_RAW_DATA, $iv, $tag );
		if ( false === $secret || '' === $secret ) {
			return new WP_Error( 'security_center_crypto_failed', 'The saved shared secret cannot be decrypted.' );
		}
		return $secret;
	}

	private static function redirect_with_notice( $notice ) {
		wp_safe_redirect( add_query_arg( 'security_center_notice', $notice, admin_url( 'admin.php?page=security-center-agent' ) ) );
		exit;
	}
}

Security_Center_Agent::boot();
register_activation_hook( __FILE__, array( 'Security_Center_Agent', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Security_Center_Agent', 'deactivate' ) );
