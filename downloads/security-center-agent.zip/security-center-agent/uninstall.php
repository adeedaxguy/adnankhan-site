<?php
/**
 * Security Center for WordPress uninstall routine.
 *
 * Scan records and quarantined files are intentionally retained. Deleting them
 * automatically would remove recovery evidence and could make a safe restore
 * impossible. Administrators can remove them only after manual review.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

wp_clear_scheduled_hook( 'security_center_agent_heartbeat' );
