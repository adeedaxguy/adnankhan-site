=== Lofts Security Center for WordPress ===
Contributors: lofts-studio
Tags: security, malware, quarantine, integrity, monitoring
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Local-first WordPress file safety checks with reversible quarantine and optional signed Lofts health reporting.

== Description ==

Lofts Security Center for WordPress keeps the response on the WordPress site:

* checks writable upload and cache paths for executable or disguised PHP;
* compares available WordPress core files to WordPress.org checksums;
* lets an administrator quarantine one reviewed finding at a time;
* preserves the quarantined copy with a non-executable extension and provides a restore action;
* can pair with a future managed Lofts workspace through a short-lived one-time code and send signed health heartbeats.

The plugin does not upload site files, does not expose a shell, does not accept remote commands, and never bulk-deletes findings.

== Installation ==

1. Download `security-center-agent.zip` from Lofts Studio.
2. In WordPress, open Plugins > Add New > Upload Plugin and upload the ZIP.
3. Activate Lofts Security Center for WordPress.
4. Open Lofts Security in the WordPress admin menu.
5. Run a local safety scan. A Lofts account or connection code is not required for local scanning or quarantine.

== Safe removal flow ==

1. Run a local safety scan.
2. Read each evidence item before acting.
3. Use Quarantine safely for an executable or disguised file in a writable path.
4. Verify the site still works. Restore the exact file if needed.
5. For WordPress core checksum mismatches, review WordPress updates or perform a clean reinstall after taking a backup.

== Frequently asked questions ==

= Does this guarantee my website is clean? =

No. A clean result is not proof that a site is secure. The plugin is intentionally conservative and exposes evidence for review.

= Why is there no delete button? =

Quarantine removes the selected file from its live executable path while retaining a restore route. Permanent deletion has no safe generic undo path.

= What happens on uninstall? =

The plugin stops its heartbeat schedule but leaves local scan records and quarantine artifacts intact so recovery evidence is not deleted automatically.
